package 프로그래머스2020상반기;

public class Solution1 {

	public int solution(String p, String s) {
		int pi,si;
		int rst = 0;
		int tmp;
		for(int i = 0; i < p.length(); i++) {
			pi = p.charAt(i)-'0';
			si = s.charAt(i)-'0';
			if(pi < si) {
				tmp = pi;
				pi = si;
				si = tmp;
			}
			rst += Math.min(pi-si, Math.abs(10+si-pi));
		}
		return rst;
	}
	public static void main(String[] args) {
		Solution1 sol = new Solution1();
		System.out.println(sol.solution("82195", "64723"));
	}
}
