package 프로그래머스2020상반기;

public class Solution2 {

	public int solution(int[][] office, int y, int x, String[] move) {
	    int[] dx = {0, 1, 0, -1};
	    int[] dy = {-1, 0, 1, 0};
	    int n = office.length;
	    int tx,ty;
	    int dir = 0;
	    int rst = office[y][x];
	    office[y][x] = 0;
	    for(int m = 0; m < move.length; m++) {
	    	if(move[m].equals("go")) {
	    		tx = x + dx[dir];
	    		ty = y + dy[dir];
	    		if(tx < 0 || ty < 0 || tx >= n|| ty >= n || office[ty][tx] < 0) {
	    			continue;
	    		}
	    		rst += office[ty][tx];
	    		office[ty][tx] = 0;
	    		x = tx;
	    		y = ty;
	    	}else if(move[m].equals("left")) {
	    		dir = dir -1;
	    		if(dir < 0) {
	    			dir = 3;
	    		}
	    	}else {
	    		//right
	    		dir = (dir +1) % 4;
	    	}
	    }
	    return rst;
	}

	public static void main(String[] args) {
		Solution2 sol = new Solution2();
		System.out.println(sol.solution(new int[][] { { 5, -1, 4 }, { 6, 3, -1 }, { 2, -1, 1 } }, 1, 0,
				new String[] { "go", "go", "right", "go", "right", "go", "left", "go" }));

	}
}
