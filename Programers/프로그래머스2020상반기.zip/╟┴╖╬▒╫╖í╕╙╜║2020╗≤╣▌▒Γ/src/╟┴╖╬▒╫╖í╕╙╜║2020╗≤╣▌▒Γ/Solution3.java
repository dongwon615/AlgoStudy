package 프로그래머스2020상반기;

import java.util.HashMap;

public class Solution3 {
	public int solution(int[] numbers, int K) {
		HashMap<String, Integer> memo = new HashMap<String, Integer>();
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < numbers.length; i++) {
			sb.append(i);
		}
		return dfs(sb.toString(),numbers,K,0,memo);
	}
	
	private int dfs(String present, int[] numbers, int K,int cnt,HashMap<String,Integer> memo) {
		if(memo.containsKey(present)) {
			if(memo.get(present)== -1) {
				return -1;
			}
			if(memo.get(present) <= cnt) {
				return memo.get(present);
			}
		}
		if(isK(present, numbers, K)) {
			return 0;
		}
		memo.put(present,-1);
		int now = Integer.MAX_VALUE;
		char[] pre = present.toCharArray();
		char tmp;
		int tmpi;
		for(int i = 0; i < present.length()-1; i++) {
			for(int j = i+1; j < present.length(); j++) {
				tmp = pre[i];
				pre[i] = pre[j];
				pre[j] = tmp;
				tmpi = dfs(String.copyValueOf(pre), numbers, K,cnt+1, memo);
				tmp = pre[i];
				pre[i] = pre[j];
				pre[j] = tmp;
				if(tmpi!=-1) {
					now = Math.min(now, tmpi + 1);
				}
			}
		}
		now = now == Integer.MAX_VALUE ? -1 : now;
		memo.put(present, now);
		return now;
	}
	private boolean isK(String s, int[] numbers, int K) {
		for(int i = 0; i < s.length()-1; i++) {
			if(Math.abs(numbers[s.charAt(i)-'0'] - numbers[s.charAt(i+1) -'0']) > K) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		Solution3 sol = new Solution3();
		System.out.println(sol.solution(new int[] {10, 40, 30, 20}, 20));
	}
}
