import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Solution3 {
	static Map<String,Integer> chkGem;
    public int[] solution(String[] gems) {
        Set<String> gem = new HashSet();
        for (String s : gems) {
        	gem.add(s);
        }
        chkGem = new HashMap<>();
        for (String s : gem) {
        	chkGem.put(s, 0);
        }
        int left;
        int right;
        //일단 보석 다 담겨있는 상태 만들고
        int tempi;
        for(right = 0; right < gems.length; right++) {
        	tempi = chkGem.get(gems[right]);
        	chkGem.put(gems[right],tempi+1);
        	if(isAllGem()) {
        		break;
        	}
        }
        //최소의 형태로 만들어줌
        int rstl = 0, rstr = 0, rstnum = 0;
        for(left = 0; left < right+1; left++) {
        	tempi = chkGem.get(gems[left]);
        	if(tempi > 1) {
        		chkGem.put(gems[left],tempi-1);
        		continue;
        	}
        	//최소니까 rst에 넣어.
        	rstl = left;
        	rstr = right;
        	rstnum = right - left + 1;
        	break;
        }
        
        String lastgem;
        // 이제 왼쪽꺼 하나 빼고 다시 그 보석 나올때까지 가고.. 만나면 left를 최소로 줄이면 됨.
        while(true) {
        	lastgem = gems[left++];
        	right++;
        	for(; right < gems.length; right++) {
        		if(lastgem.equals(gems[right])) {
        			break;
        		}
        		tempi = chkGem.get(gems[right]);
        		chkGem.put(gems[right],tempi+1);
        	}
        	//더이상 같은보석이 없으면 끝
        	if(right == gems.length) {
        		break;
        	}
        	//같은보석 찾은거임 -> 왼쪽을 최소로 줄여
        	
        	for(; left < right+1; left++) {
            	tempi = chkGem.get(gems[left]);
            	if(tempi > 1) {
            		chkGem.put(gems[left],tempi-1);
            		continue;
            	}
            	//최소니까 길이가 이전보다 짧으면 최신화
            	if((right - left + 1) < rstnum) {
            		rstl = left;
            		rstr = right;
            		rstnum = right - left + 1;
            	}
            	break;
            }
        }
        return new int[] {rstl+1,rstr+1};
    }
    
	private boolean isAllGem() {
		for (Entry<String, Integer> es : chkGem.entrySet()) {
			if(es.getValue() == 0) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		Solution3 sol = new Solution3();
		String[] inp = new String[50000];
		inp[0] = "DIA";
		for(int i = 1; i < 50000; i++) {
			inp[i] = "RUBY";
		}
		inp[49998] = "ZZ";
		inp[49999] = "DIA";
		
		int[] rst = sol.solution(inp);
//		int[] rst = sol.solution(new String[] {"DIA", "RUBY", "RUBY", "DIA", "DIA", "EMERALD", "SAPPHIRE", "DIA"});
		for(int i = 0; i < 2; i++) {
			System.out.print(rst[i] + " ");
		}
	}
}

