
public class Solution4 {
	static int n;
	static int rst;
	static int corner;
	static int memo[][][];
	public int solution(int[][] board) {
        n = board.length;
        rst = Integer.MAX_VALUE;
        corner = Integer.MAX_VALUE;
        //해당지점 도착했을때 여태껏 sum이 작은지
        memo = new int[n][n][5];
        //처음 틀어서 가기때문에 500원빼야함.
        dfs(board,0,0,4,0,0);
        rst -= 500;
        return rst;
    }
	static int[] dx = {0, 1, 0, -1}; // 위 오 아래 왼
	static int[] dy = {-1, 0, 1, 0};
	//dir 0 1 2 3로 위 오 아래 왼 순서
	private void dfs(int[][] board, int x, int y, int dir, int sum, int corn) {
		//가지치기
		if(sum >= rst) {
			return;
		}
		
		if(memo[y][x][dir] != 0) {
			if(memo[y][x][dir] < sum) {
				return;
			}
		}
		memo[y][x][dir] = sum;
		
		//마지막지점 도착시
		if (x == n-1 && y == n-1) {
			if(sum <= rst) {
				rst = sum;
				corner = Math.min(corner, corn);
			}
			return;
		}
		//4방향 다 가봐 : 시간초과나니까.. 가던방향을 먼저 탐색하면 가능할듯. 아님 그래도 효율 업..
		
		int tx, ty;
		int d = 0;
		for (int i = 0; i < 4; i++) {
			d = (dir + i) % 4;
			tx = x + dx[d];
			ty = y + dy[d];
			if (tx < 0 || ty < 0 || tx >= n || ty >= n || board[ty][tx] == 1) {
				continue;
			} 
			//벽아니면 직선인지 코너인지에 따라 가격구하기
			int price;
			int tcorn = corn;
			price = dir == d ? 100 : 600;
			if(price > 100) {
				tcorn++;
			}
			board[y][x] = 1;
			dfs(board, tx, ty, d, sum+price, tcorn);
			board[y][x] = 0;
		}
		
		
	}

	public static void main(String[] args) {
		Solution4 sol = new Solution4();
		int rst = sol.solution(new int[][] {{0,0,0,0,0,0},{0,1,1,1,1,0},{0,0,1,0,0,0},{1,0,0,1,0,1},{0,1,0,0,0,1},{0,0,0,0,0,0}});
		System.out.println(rst);
	}
}
