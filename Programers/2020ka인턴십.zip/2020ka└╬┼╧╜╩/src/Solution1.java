import java.util.HashMap;
import java.util.Map;

public class Solution1 {
	static class Point{
		int x,y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}
		
	}
    public String solution(int[] numbers, String hand) {
        Map<Character,Point> phone = new HashMap<>();
        phone.put('1', new Point(0,0));
        phone.put('2', new Point(1,0));
        phone.put('3', new Point(2,0));
        phone.put('4', new Point(0,1));
        phone.put('5', new Point(1,1));
        phone.put('6', new Point(2,1));
        phone.put('7', new Point(0,2));
        phone.put('8', new Point(1,2));
        phone.put('9', new Point(2,2));
        phone.put('*', new Point(0,3));
        phone.put('0', new Point(1,3));
        phone.put('#', new Point(2,3));
        Point left = phone.get('*');
        Point right = phone.get('#');
        StringBuilder sb = new StringBuilder();
        Point click;
        int dist1,dist2;
        for (int i = 0; i < numbers.length; i++) {
        	click = phone.get(Character.forDigit(numbers[i], 10));
        	//147누르면
        	if(numbers[i] == 1 || numbers[i] == 4 || numbers[i] == 7) {
        		sb.append("L");
    			left = click;
    			continue;
        	}
        	//369누르면
        	if(numbers[i] == 3 || numbers[i] == 6 || numbers[i] == 9) {
        		sb.append("R");
        		right = click;
        		continue;
        	}
        	//2580누르면
        	dist1 = dist(left,click);
        	dist2 = dist(right,click);
        	
        	//거리같으면 hand에 따라
        	if (dist1 == dist2) {
        		if (hand.equals("left")) {
        			sb.append("L");
        			left = click;
        			continue;
        		}
        		sb.append("R");
        		right = click;
        		continue;
        	}
        	
        	//다르면 가까운손
        	if (dist1 < dist2) {
        		sb.append("L");
    			left = click;
    			continue;
        	}else {
        		sb.append("R");
        		right = click;
        		continue;
        	}
        }
        return sb.toString();
    }
	private int dist(Point left, Point click) {
		return Math.abs(click.y-left.y) + Math.abs(click.x-left.x);
	}
	public static void main(String[] args) {
		Solution1 sol = new Solution1();
		String s = sol.solution(new int[] {1, 3, 4, 5, 8, 2, 1, 4, 5, 9, 5}, "right");
		System.out.println(s);
	}
}
